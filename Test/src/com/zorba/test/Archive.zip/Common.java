package com.zorba.test;

public interface Common {
public void addStd();
public void deleteStd();
public void displayStd();


}
