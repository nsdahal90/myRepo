package com.zorba.test;

public abstract class StudentDemo implements Common {

	@Override
	public abstract void addStd();
		

	@Override
	public void deleteStd() {
		
		
	}

	@Override
	public void displayStd() {
		System.out.println("This is the display method");
		
	}

}
