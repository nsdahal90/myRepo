package com.zorba.test;

public class TestDemo {
	public static void main(String[] args) {
		
	
Student std = new Student("Nischal","Florida");



}
}